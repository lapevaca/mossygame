<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="vines" tilewidth="195" tileheight="270" tilecount="20" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="93" height="270" source="CHARSprites/Mossy Assets/Mossy Tileset/vine1.png"/>
 </tile>
 <tile id="1">
  <image width="92" height="268" source="CHARSprites/Mossy Assets/Mossy Tileset/vine2.png"/>
 </tile>
 <tile id="2">
  <image width="78" height="231" source="CHARSprites/Mossy Assets/Mossy Tileset/vine3.png"/>
 </tile>
 <tile id="3">
  <image width="72" height="191" source="CHARSprites/Mossy Assets/Mossy Tileset/vine4.png"/>
 </tile>
 <tile id="4">
  <image width="71" height="191" source="CHARSprites/Mossy Assets/Mossy Tileset/vine5.png"/>
 </tile>
 <tile id="5">
  <image width="60" height="161" source="CHARSprites/Mossy Assets/Mossy Tileset/vine6.png"/>
 </tile>
 <tile id="6">
  <image width="54" height="186" source="CHARSprites/Mossy Assets/Mossy Tileset/vine7.png"/>
 </tile>
 <tile id="7">
  <image width="149" height="101" source="CHARSprites/Mossy Assets/Mossy Tileset/vine8.png"/>
 </tile>
 <tile id="8">
  <image width="149" height="100" source="CHARSprites/Mossy Assets/Mossy Tileset/vine9.png"/>
 </tile>
 <tile id="9">
  <image width="150" height="100" source="CHARSprites/Mossy Assets/Mossy Tileset/vine10.png"/>
 </tile>
 <tile id="10">
  <image width="195" height="84" source="CHARSprites/Mossy Assets/Mossy Tileset/plant4.png"/>
 </tile>
 <tile id="11">
  <image width="162" height="107" source="CHARSprites/Mossy Assets/Mossy Tileset/plant5.png"/>
 </tile>
 <tile id="12">
  <image width="122" height="113" source="CHARSprites/Mossy Assets/Mossy Tileset/plant6.png"/>
 </tile>
 <tile id="13">
  <image width="170" height="94" source="CHARSprites/Mossy Assets/Mossy Tileset/plant1.png"/>
 </tile>
 <tile id="14">
  <image width="151" height="69" source="CHARSprites/Mossy Assets/Mossy Tileset/plant2.png"/>
 </tile>
 <tile id="15">
  <image width="140" height="121" source="CHARSprites/Mossy Assets/Mossy Tileset/plant3.png"/>
 </tile>
 <tile id="16">
  <image width="56" height="194" source="CHARSprites/Mossy Assets/Mossy Tileset/plant7.png"/>
 </tile>
 <tile id="17">
  <image width="58" height="196" source="CHARSprites/Mossy Assets/Mossy Tileset/plant8.png"/>
 </tile>
 <tile id="18">
  <image width="57" height="196" source="CHARSprites/Mossy Assets/Mossy Tileset/plant9.png"/>
 </tile>
 <tile id="19">
  <image width="33" height="199" source="CHARSprites/Mossy Assets/Mossy Tileset/plant10.png"/>
 </tile>
</tileset>
