<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="begin_end" tilewidth="77" tileheight="77" tilecount="2" columns="2">
 <image source="CHARSprites/Mossy Assets/Mossy Tileset/begin_end.png" width="154" height="77"/>
</tileset>
