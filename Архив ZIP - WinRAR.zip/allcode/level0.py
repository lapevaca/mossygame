level0_map = {
    'character': 'C:/Users/User/PycharmProjects/pythonProject2/CHARSprites/leveltile/TILESET0._beginend.csv',
    'tileMAP': 'C:/Users/User/PycharmProjects/pythonProject2/CHARSprites/leveltile/TILESET0._tilemap.csv',
    'enemySLIME': 'C:/Users/User/PycharmProjects/pythonProject2/CHARSprites/leveltile/TILESET0._enemyslime.csv',
    'lightCOIN': 'C:/Users/User/PycharmProjects/pythonProject2/CHARSprites/leveltile/TILESET0._light.csv',
    'tilemapBEHIND': 'C:/Users/User/PycharmProjects/pythonProject2/CHARSprites/leveltile/TILESET0._behindmap.csv',
    'spikes': 'C:/Users/User/PycharmProjects/pythonProject2/CHARSprites/leveltile/TILESET0._spikes.csv',
    'vines': 'C:/Users/User/PycharmProjects/pythonProject2/CHARSprites/leveltile/TILESET0._vines.csv',
    'plant': 'C:/Users/User/PycharmProjects/pythonProject2/CHARSprites/leveltile/TILESET0._leaves.csv',
    'rockTALL': 'C:/Users/User/PycharmProjects/pythonProject2/CHARSprites/leveltile/TILESET0._rock1.csv',
    'rockSMALL': 'C:/Users/User/PycharmProjects/pythonProject2/CHARSprites/leveltile/TILESET0._rock2.csv'
}
