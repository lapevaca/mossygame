import pygame
from os import walk

def importpath(path):
    surf = []
    for i, j, img_file in walk(path):
        for image in img_file:
            full_path = path + '/' + image
            image_surf = pygame.image.load(full_path).convert_alpha()
            surf.append(image_surf)
    return surf


class CHARACTER(pygame.sprite.Sprite):
    def __init__(self, pos,  surface):
        super().__init__()
        self.display_surface = surface
        self.CHARACTERSPRITES()
        self.frameINDEX = 0
        self.animationSPEED = 0.15
        self.image = self.character_animation['2BlueWizardIdle'][self.frameINDEX]
        self.rect = self.image.get_rect(topleft=pos)


        self.direction = pygame.math.Vector2()
        self.speed = 8
        self.gravity = 0.8
        self.jumpSPEED = -20

        # статус персонажа
        self.status = 'idle'
        self.facingside = True
        self.onground = False
        self.ontop = False
        self.onleft = False
        self.onright = False


    def CHARACTERSPRITES(self):
        characterPATH = 'C:/Users/User/PycharmProjects/pythonProject2/CHARSprites/'
        self.character_animation = {'2BlueWizardIdle': [], '2BlueWizardJump': [], '2BlueWizardWalk': [],
                                    '2BlueWizardFall': []}
        for animation in self.character_animation.keys():
            path = characterPATH + animation
            self.character_animation[animation] = importpath(path)


    def ANIMATION(self):
        animation = self.character_animation[self.status]

        self.frameINDEX += self.animationSPEED
        if self.frameINDEX >= len(animation):
            self.frameINDEX = 0

        img = self.image = animation[int(self.frameINDEX)]
        if self.facingside:
            self.image = img
        else:
            imageFLIP = pygame.transform.flip(img, True, False)
            self.image = imageFLIP

        if self.onground and self.onright:
            self.rect = self.image.get_rect(bottomright=self.rect.bottomright)
        elif self.onground and self.onleft:
            self.rect = self.image.get_rect(bottomleft=self.rect.bottomleft)
        elif self.onground:
            self.rect = self.image.get_rect(midbottom=self.rect.midbottom)
        elif self.ontop and self.onright:
            self.rect = self.image.get_rect(topright=self.rect.topright)
        elif self.ontop and self.onleft:
            self.rect = self.image.get_rect(topleft=self.rect.topleft)
        elif self.ontop:
            self.rect = self.image.get_rect(midtop=self.rect.midtop)

    def PRESSKEY(self):
        key = pygame.key.get_pressed()

        if key[pygame.K_RIGHT] or key[pygame.K_d]:
            self.direction.x = 1
            self.facingside = True
        elif key[pygame.K_LEFT] or key[pygame.K_a]:
            self.direction.x = -1
            self.facingside = False
        else:
            self.direction.x = 0
        if key[pygame.K_SPACE] and self.onground:
            self.direction.y = -self.jumpSPEED


    def STATUS(self):
        # если
        if self.direction.y < 0:
            self.status = '2BlueWizardJump'
        elif self.direction.y > 0:
            self.status = '2BlueWizardFall'
        else:
            if self.direction.x != 0:
                self.status = '2BlueWizardWalk'
            else:
                self.status = '2BlueWizardIdle'


    def GRAVITY(self):
        self.direction.y += self.gravity
        self.rect.y += self.direction.y


    def update(self):

        self.PRESSKEY()
        self.STATUS()
        self.ANIMATION()
