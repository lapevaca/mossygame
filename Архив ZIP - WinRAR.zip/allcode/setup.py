vertical_tile_number = 30
tileSIZE = 77
screen_width = 1350
screen_height = 750
horizontal_tile_number = 40
