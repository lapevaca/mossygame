import pygame, sys
from character import CHARACTER
from level0 import level0_map
from level1 import LEVEL, CAMERA
from setup import *
pygame.init()

screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption('Mossy forest')
clock = pygame.time.Clock()
level = LEVEL(level0_map, screen)
camera = CAMERA()
character = CHARACTER((screen_width / 2, screen_height / 2), camera)
while True:
    # global finish
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

    screen.fill('gray')
    level.RUN()
    camera.update()
    camera.customdraw(character)


    pygame.display.update()
    clock.tick(40)
