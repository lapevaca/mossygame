from csv import reader
from setup import *
import pygame
from os import walk

def import_folder(path):
    surf = []
    for i, j, img_file in walk(path):
        for image in img_file:
            full_path = path + '/' + image
            image_surf = pygame.image.load(full_path).convert_alpha()
            surf.append(image_surf)
    return surf


def import_csv_layout(path):
    tile_MAP = []
    with open(path) as map:
        level = reader(map, delimiter=',')
        for row in level:
            tile_MAP.append(list(row))
        return tile_MAP

def import_cut(path):
    surface = pygame.image.load(path).convert_alpha()
    tileNUMX = int(surface.get_size()[0] / tileSIZE)
    tileNUMY = int(surface.get_size()[1] / tileSIZE)

    cut_tiles = []
    for row in range(tileNUMY):
        for col in range(tileNUMX):
            x = col * tileSIZE
            y = row * tileSIZE
            new_surface = pygame.Surface((tileSIZE, tileSIZE), pygame.SRCALPHA, 32)
            new_surface.blit(surface, (0,0), pygame.Rect(x,y,tileSIZE, tileSIZE))
            cut_tiles.append(new_surface)
    return cut_tiles