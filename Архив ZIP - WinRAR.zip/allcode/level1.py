import pygame
from importcsv import import_csv_layout, import_cut
from tiles import STATICFILE, COIN, VINE, PLANT, SPIKES, ROCKTALL, ROCKSMALL
from character import CHARACTER
from setup import *



class LEVEL:
    def __init__(self, level_data, surface):
        self.display_surface = surface
        self.active_sprites = pygame.sprite.Group()
        self.collision_sprites = pygame.sprite.Group()

        character_layout = import_csv_layout(level_data['character'])
        self.character = pygame.sprite.GroupSingle()
        self.goal = pygame.sprite.GroupSingle()
        self.character_setup(character_layout)

        self.camera = CAMERA()

        tileBACK_layout = import_csv_layout(level_data['tilemapBEHIND'])
        self.tileBACK_map = self.level_structure(tileBACK_layout, 'tilemapBEHIND')

        tile_layout = import_csv_layout(level_data['tileMAP'])
        self.tile_map = self.level_structure(tile_layout, 'tileMAP')

        light_layout = import_csv_layout(level_data['lightCOIN'])
        self.light_map = self.level_structure(light_layout, 'lightCOIN')

        vine_layout = import_csv_layout(level_data['vines'])
        self.vine_map = self.level_structure(vine_layout, 'vines')

        spikes_layout = import_csv_layout(level_data['spikes'])
        self.spikes_map = self.level_structure(spikes_layout, 'spikes')

        plant_layout = import_csv_layout(level_data['plant'])
        self.plant_map = self.level_structure(plant_layout, 'plant')

        rockTall_layout = import_csv_layout(level_data['rockTALL'])
        self.rockTALL_map = self.level_structure(rockTall_layout, 'rockTALL')

        rockSmall_layout = import_csv_layout(level_data['rockSMALL'])
        self.rockSMALL_map = self.level_structure(rockSmall_layout, 'rockSMALL')
        '''
        enemyslime_layout = import_csv_layout(level_data['enemySLIME'])
        self.enemyslime_map = self.level_structure(enemyslime_layout, 'enemySLIME')'''

    def level_structure(self, layout, type):
        sprite_group = CAMERA()

        for lineX_index, lineX in enumerate(layout):
            for lineY_index, lineY in enumerate(lineX):
                if lineY != '-1':
                    x = lineY_index * tileSIZE
                    y = lineX_index * tileSIZE
                    if type == 'tileMAP':
                        terrain_tile = import_cut('C:/Users/User/PycharmProjects/pythonProject2/CHARSprites/Mossy '
                                                  'Assets/Mossy Tileset/Mossy - TileSet17922.png')
                        tile_surface = terrain_tile[int(lineY)]
                        sprite = STATICFILE(tileSIZE, x, y, tile_surface)

                    if type == 'tilemapBEHIND':
                        terrain_tile = import_cut('C:/Users/User/PycharmProjects/pythonProject2/CHARSprites/Mossy '
                                                  'Assets/Mossy Tileset/Mossy - TileSet1792TRANS.png')
                        tile_surface = terrain_tile[int(lineY)]
                        sprite = STATICFILE(tileSIZE, x, y, tile_surface)

                    if type == 'lightCOIN':
                        sprite = COIN(tileSIZE, x, y)

                    if type == 'vines':
                        sprite = VINE(tileSIZE, x, y)

                    if type == 'plant':
                        sprite = PLANT(tileSIZE, x, y)

                    if type == 'spikes':
                        sprite = SPIKES(tileSIZE, x, y)

                    if type == 'rockTALL':
                        sprite = ROCKTALL(tileSIZE, x, y)

                    if type == 'rockSMALL':
                        sprite = ROCKSMALL(tileSIZE, x, y)
                    '''
                    if type == 'enemySLIME':
                        sprite = ANIMATEDSPRITES(tileSIZE, x, y, 'C:/Users/User/PycharmProjects/pythonProject2'
                                                                 '/CHARSprites/Slimes/SlimeGreen')'''

                    sprite_group.add(sprite)

        return sprite_group

    def character_setup(self, layout):
        for lineX_index, lineX in enumerate(layout):
            for lineY_index, lineY in enumerate(lineX):
                x = lineY_index * tileSIZE
                y = lineX_index * tileSIZE
                if lineY != '0':
                    sprite = CHARACTER((x, y), self.display_surface)
                    self.character.add(sprite)
                if lineY != '1':
                    end = pygame.image.load('C:/Users/User/PycharmProjects/pythonProject2/CHARSprites/Mossy '
                                            'Assets/Mossy Tileset/light.png').convert_alpha()
                    sprite = STATICFILE(tileSIZE, x, y, end)
                    self.goal.add(sprite)

    def horizontal_movement_collision(self):
        character = self.character.sprite
        character.rect.x += character.direction.x * character.speed
        collidable_sprites = self.tile_map.sprites()
        for sprite in collidable_sprites:
            if sprite.rect.colliderect(character.rect):
                if character.direction.x < 0:
                    character.rect.left = sprite.rect.right
                    character.onleft = True
                    self.current_x = character.rect.left
                elif character.direction.x > 0:
                    character.rect.right = sprite.rect.left
                    character.onright = True
                    self.current_x = character.rect.right

        if character.onleft and (character.rect.left < self.current_x or character.direction.x >= 0):
            character.onleft = False
        if character.onright and (character.rect.right > self.current_x or character.direction.x <= 0):
            character.onright = False

    def vertical_movement_collision(self):
        character = self.character.sprite
        character.GRAVITY()
        collidable_sprites = self.tile_map.sprites()

        for sprite in collidable_sprites:
            if sprite.rect.colliderect(character.rect):
                if character.direction.y > 0:
                    character.rect.bottom = sprite.rect.top
                    character.direction.y = 0
                    character.onground = True
                elif character.direction.y < 0:
                    character.rect.top = sprite.rect.bottom
                    character.direction.y = 0
                    character.ontop = True

        if character.onground and character.direction.y < 0 or character.direction.y > 1:
            character.onground = False
        if character.ontop and character.direction.y > 0.1:
            character.ontop = False

    def RUN(self):
        self.tileBACK_map.customdraw(self.character.sprite)
        self.tile_map.customdraw(self.character.sprite)

        self.light_map.customdraw(self.character.sprite)
        # self.enemyslime_map.customdraw(self.character.sprite)
        self.vine_map.customdraw(self.character.sprite)
        self.plant_map.customdraw(self.character.sprite)
        self.spikes_map.customdraw(self.character.sprite)
        self.rockTALL_map.customdraw(self.character.sprite)
        self.rockSMALL_map.customdraw(self.character.sprite)
        self.character.draw(self.display_surface)
        self.goal.draw(self.display_surface)
        self.horizontal_movement_collision()
        self.vertical_movement_collision()


class CAMERA(pygame.sprite.Group):
    def __init__(self):
        super().__init__()
        self.display_surface = pygame.display.get_surface()
        self.cameraBORDERS = {'left': 200, 'right': 200, 'top': 100, 'bottom': 100}
        self.offset = pygame.math.Vector2()
        self.internal_offset = pygame.math.Vector2()
        l = self.cameraBORDERS['left']
        t = self.cameraBORDERS['top']
        w = self.display_surface.get_size()[0] - (self.cameraBORDERS['left'] + self.cameraBORDERS['top'])
        h = self.display_surface.get_size()[1] - (self.cameraBORDERS['top'] + self.cameraBORDERS['bottom'])
        self.camera_rect = pygame.Rect(l, t, w, h)

    def cameratarget(self, character):
        if character.rect.left < self.camera_rect.left:
            self.camera_rect.left = character.rect.left
        if character.rect.right > self.camera_rect.right:
            self.camera_rect.right = character.rect.right
        if character.rect.top < self.camera_rect.top:
            self.camera_rect.top = character.rect.top
        if character.rect.bottom > self.camera_rect.bottom:
            self.camera_rect.bottom = character.rect.bottom

        self.offset.x = self.camera_rect.left - self.cameraBORDERS['left']
        self.offset.y = self.camera_rect.top - self.cameraBORDERS['top']

    def customdraw(self, character):
        self.cameratarget(character)
        for sprite in sorted(self.sprites(), key=lambda sprite: sprite.rect.centery):
            offset_pos = sprite.rect.topleft - self.offset
            self.display_surface.blit(sprite.image, offset_pos)
